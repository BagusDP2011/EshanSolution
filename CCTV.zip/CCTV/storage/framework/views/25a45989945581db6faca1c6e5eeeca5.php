<?php echo $__env->make('layouts.navigator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-semibold text-center mb-6">Produk Kami</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php if(!$products): ?>
        <p>Produk tidak ada atau gagal menampilkannya</p>
        <?php endif; ?>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white shadow-lg rounded-lg p-4 transition transform hover:scale-105">
                <img src="<?php echo e(url( $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-48 object-cover rounded-md">
                <h2 class="text-lg font-semibold mt-4"><?php echo e($product->name); ?></h2>
                <p class="text-gray-600 text-sm mt-2"><?php echo e($product->description); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Pagination -->
    <div class="mt-6 flex justify-center">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\CCTV\resources\views/products.blade.php ENDPATH**/ ?>